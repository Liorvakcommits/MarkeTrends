const hre = require("hardhat");
const fs = require("fs");

async function main() {
    console.log("🚀 Deploying ConditionalTokens (Gnosis)...");

    const [deployer] = await hre.ethers.getSigners();
    console.log("🔹 Deployer address:", deployer.address);

    // קבלת חוזה 
    const ConditionalTokens = await hre.ethers.getContractFactory("ConditionalTokens");

    // פריסה
    const conditionalTokens = await ConditionalTokens.deploy();
    await conditionalTokens.waitForDeployment();

    // בדיקת כתובת
    const conditionalTokensAddress = await conditionalTokens.getAddress();
    console.log("✅ ConditionalTokens deployed at:", conditionalTokensAddress);

    if (!conditionalTokensAddress) {
        console.error("❌ Error: conditionalTokensAddress is undefined!");
        process.exit(1);
    }

    // שמירת הכתובת לקובץ
    fs.writeFileSync("./deployed_conditional_tokens.txt", conditionalTokensAddress);
    console.log("📄 ConditionalTokens address saved to deployed_conditional_tokens.txt");
}

main().catch((error) => {
    console.error("❌ Deployment failed:", error);
    process.exitCode = 1;
});

