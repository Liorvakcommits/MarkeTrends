const fs = require("fs");
const path = require("path");

async function main() {
    // קרא את הכתובת העדכנית של החוזה מהקובץ
    const contractAddress = fs.readFileSync("./deployed_address.txt", "utf8").trim();

    // טען את קובץ ה-Metadata הקיים
    const metadataPath = path.join(__dirname, "../metadata/mtc.json");
    const metadata = JSON.parse(fs.readFileSync(metadataPath, "utf8"));

    // עדכן את כתובת החוזה ב-Metadata
    metadata.contractAddress = contractAddress;

    // שמור את הקובץ המעודכן
    fs.writeFileSync(metadataPath, JSON.stringify(metadata, null, 4));

    console.log(`✅ Metadata updated successfully with contract address: ${contractAddress}`);
}

main().catch((error) => {
    console.error("❌ Error updating metadata:", error);
    process.exit(1);
});
