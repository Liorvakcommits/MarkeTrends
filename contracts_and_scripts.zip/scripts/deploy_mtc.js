const hre = require("hardhat");
const fs = require("fs");

async function main() {
    console.log("🚀 Deploying MarkeTrends Coins (MTC)...");

    const [deployer] = await hre.ethers.getSigners();
    console.log("🔹 Deployer address:", deployer.address);

    // יצירת חוזה ERC-20
    const MTC = await hre.ethers.getContractFactory("MTC");
    const initialSupply = hre.ethers.parseUnits("1000000", 18); // 1,000,000 MTC
    const mtcToken = await MTC.deploy(initialSupply);

    await mtcToken.waitForDeployment();

    // שמירת כתובת הטוקן
    const mtcAddress = await mtcToken.getAddress();
    console.log("✅ MarkeTrends Coins (MTC) deployed at:", mtcAddress);

    // שמירת הכתובת בקובץ
    fs.writeFileSync("./deployed_mtc_token.txt", mtcAddress);
    console.log("📄 MTC address saved to deployed_mtc_token.txt");
}

main().catch((error) => {
    console.error("❌ Deployment failed:", error);
    process.exitCode = 1;
});
