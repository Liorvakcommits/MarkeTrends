const hre = require("hardhat");
const fs = require("fs");
const { execSync } = require("child_process");
const CONDITIONAL_TOKENS_ADDRESS = "0xA8Cc778572FD192d1aCDDc520C144db7a6ae1547"; // 🔄 כתובת חדשה
const COLLATERAL_TOKEN_ADDRESS = "0x4b9DEbd77a5ee07DFD4637629F743E3195a34A3e"; // MTC - MarkeTrends Coins (ERC-20)
const ORACLE_ADDRESS = "0x326C977E6efc84E512bB9C30f76E30c160eD06FB"; // Chainlink Oracle (Polygon Mainnet)

async function main() {
    console.log("🚀 Starting deployment process...");

    const [deployer] = await hre.ethers.getSigners();
    console.log("🔹 Deploying contracts with account:", deployer.address);

    // ✅ שלב 1: פריסת MarketManagerHelper
    console.log("🔹 Deploying MarketManagerHelper...");
    const MarketManagerHelper = await hre.ethers.getContractFactory("MarketManagerHelper");
    const marketManagerHelper = await MarketManagerHelper.deploy(deployer.address);
    await marketManagerHelper.waitForDeployment();
    const marketManagerHelperAddress = await marketManagerHelper.getAddress();
    console.log("✅ MarketManagerHelper deployed at:", marketManagerHelperAddress);

    // ✅ Debug - הדפסת הכתובות שאנו מעבירים לפריסה של MarketManager
    console.log("🔍 Debugging Parameters for MarketManager Deployment:");
    console.log("Conditional Tokens Address:", CONDITIONAL_TOKENS_ADDRESS);
    console.log("Collateral Token Address:", COLLATERAL_TOKEN_ADDRESS);
    console.log("Oracle Address:", ORACLE_ADDRESS);
    console.log("MarketManagerHelper Address:", marketManagerHelperAddress);

    // ✅ שלב 2: פריסת MarketManager עם כל הכתובות
    console.log("🔹 Deploying MarketManager...");
    const MarketManager = await hre.ethers.getContractFactory("MarketManager");
    const marketManager = await MarketManager.deploy(
        CONDITIONAL_TOKENS_ADDRESS, 
        COLLATERAL_TOKEN_ADDRESS, 
        ORACLE_ADDRESS, 
        marketManagerHelperAddress
    );

    await marketManager.waitForDeployment();
    const marketManagerAddress = await marketManager.getAddress();
    console.log("✅ MarketManager deployed at:", marketManagerAddress);

    // ✅ שמירת הכתובות לקובץ
    const deploymentData = `MarketManager: ${marketManagerAddress}\nMarketManagerHelper: ${marketManagerHelperAddress}\n`;
    fs.writeFileSync("./deployed_address.txt", deploymentData);
    console.log("📄 Deployment addresses saved to deployed_address.txt");

    // ✅ עדכון Metadata
    console.log("🔄 Updating metadata...");
    execSync("node scripts/update_metadata.js", { stdio: "inherit" });
    console.log("✅ Metadata update completed!");

    console.log("🎉 Deployment successful!");
}

main().catch((error) => {
    console.error("❌ Deployment failed:", error);
    process.exitCode = 1;
});


