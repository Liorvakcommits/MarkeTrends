const hre = require("hardhat");
const fs = require("fs");

async function main() {
    console.log("🚀 Deploying MarketManagerHelper...");

    const [deployer] = await hre.ethers.getSigners();
    console.log("🔹 Deployer address:", deployer.address);

    // יצירת חוזה MarketManagerHelper
    const MarketManagerHelper = await hre.ethers.getContractFactory("MarketManagerHelper");
    const marketManagerHelper = await MarketManagerHelper.deploy(deployer.address);

    await marketManagerHelper.waitForDeployment();

    // שמירת כתובת החוזה
    const helperAddress = await marketManagerHelper.getAddress();
    console.log("✅ MarketManagerHelper deployed at:", helperAddress);

    // שמירת הכתובת בקובץ
    fs.writeFileSync("./deployed_market_helper.txt", helperAddress);
    console.log("📄 MarketManagerHelper address saved to deployed_market_helper.txt");
}

main().catch((error) => {
    console.error("❌ Deployment failed:", error);
    process.exitCode = 1;
});
